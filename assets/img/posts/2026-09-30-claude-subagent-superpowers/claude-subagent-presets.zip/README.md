# Claude Code 서브에이전트 프리셋 6종

Superpowers 티어 4종(`tier-*`) + 일상 작업 2종(`search`, `explore`).
설명과 근거: https://codefoundry-io.github.io/posts/claude-subagent-superpowers/

## 설치

1. `.claude/agents/` 를 프로젝트 루트(팀 공유) 또는 `~/.claude/agents/`(개인)에 복사한다.
2. CLAUDE.md 조각 하나를 골라 프로젝트 `CLAUDE.md`에 붙여 넣는다.
   - Superpowers를 안 쓰면 `CLAUDE.md.basic.ko.snippet` / `.en`
   - Superpowers를 쓰면 `CLAUDE.md.superpowers.ko.snippet` / `.en`
3. 세션을 다시 시작한다. 확실히 부르려면 프롬프트에서 `@agent-tier-max` 처럼 지목한다.

## 주의

- 본문이 빈 서브에이전트는 Claude Code v2.1.281 이상에서 지원한다.
- `model`은 별칭이다. 제공자가 Anthropic API가 아니거나 모델 × effort 조합을 고정하려면
  `claude-opus-5-5` 처럼 전체 ID로 바꾼다.
- `CLAUDE_CODE_SUBAGENT_MODEL_FORCE` 가 켜져 있으면 프리셋의 model 이 무시된다.
- 프리셋 파일만 두면 메인이 잘 안 부른다. CLAUDE.md 조각을 꼭 같이 넣는다.
