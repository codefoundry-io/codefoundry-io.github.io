---
name: web-research
description: 여러 웹 페이지를 읽고 대조하는 조사, 공식 문서 · 릴리스 노트 · 리더보드에서 버전 · 플래그 · 수치 확인. 출처 URL과 페이지 날짜를 같이 돌려준다
model: sonnet
effort: medium
---
