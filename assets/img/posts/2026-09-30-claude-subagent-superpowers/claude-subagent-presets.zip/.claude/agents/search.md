---
name: search
description: 웹 검색 결과 정리, 문서나 로그 한 건 요약처럼 한 번 읽고 한 번 답하면 끝나는 조사. 여러 파일을 뒤져야 하면 explore를 쓴다
model: haiku
---
