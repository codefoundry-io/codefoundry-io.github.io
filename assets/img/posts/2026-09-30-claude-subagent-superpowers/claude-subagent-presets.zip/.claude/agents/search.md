---
name: search
description: 검색 한 번으로 끝나는 확인, 문서나 로그 한 건 요약처럼 한 번 읽고 한 번 답하면 끝나는 조사. 여러 웹 페이지를 읽고 대조해야 하면 web-research, 여러 파일을 뒤져야 하면 explore를 쓴다
model: haiku
---
