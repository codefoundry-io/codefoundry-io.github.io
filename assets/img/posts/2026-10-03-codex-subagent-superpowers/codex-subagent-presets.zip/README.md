# Codex 서브에이전트 용도별 모델 · effort 7종

Superpowers 티어 4종(`tier-*`) + 일상 작업 3종(`search`, `web-research`, `explore`).
설명과 근거: https://codefoundry-io.github.io/posts/codex-subagent-superpowers/

모델과 effort는 2026-10-02 기준이다(GPT-6.1 Sol, GPT-6 Luna). 새 모델이 나오면 model 값을 바꾼다.
두 방법 중 하나만 고른다.

## 폴더 구조

```
README.md
agents-md/                 방법 1. AGENTS.md만 (기본)
  AGENTS.md.basic.*        기본판: 일상 작업 + 구현 · 리뷰 7줄 표 (model, reasoning_effort)
  AGENTS.md.superpowers.*  배선판: 일상 작업 3줄 + Superpowers 배선 표
toml-presets/              방법 2. TOML 프리셋으로 고정
  .codex/agents/*.toml     프리셋 7종
  AGENTS.md.basic.*        프리셋 이름으로 라우팅하는 판
  AGENTS.md.superpowers.*
```

`*.ko.snippet`은 한국어, `*.en.snippet`은 영어판이다.

## 방법 1. AGENTS.md만 (기본)

1. `agents-md/`에서 조각 하나를 골라 프로젝트 `AGENTS.md`(또는 `~/.codex/AGENTS.md`)에 붙여 넣는다.
   Superpowers를 쓰면 `superpowers`, 아니면 `basic`.
2. Codex 세션을 다시 시작한다.

메인이 스폰할 때마다 표의 model과 reasoning_effort를 넘기고 fork_turns는 "none"으로 넘긴다.
메인이 표를 따른다는 전제다. 다른 값을 넘기면 그 값으로 돈다.

## 방법 2. TOML 프리셋으로 고정

1. `toml-presets/.codex/agents/`를 프로젝트 루트(팀 공유) 또는 `~/.codex/`(개인)에 복사한다.
2. 같은 폴더의 조각 하나를 프로젝트 `AGENTS.md`에 붙여 넣는다.
3. Codex 세션을 다시 시작한다.

- 프리셋의 `model` / `model_reasoning_effort`는 spawn_agent 인자보다 우선한다. 호출 때 바꿀 수 없다.
  GPT-6 Astra 같은 다른 모델은 프리셋 없이 model과 reasoning_effort를 같이 넘겨서 부른다.
- 프리셋에 `sandbox_mode`를 적어도 적용되지 않는다(Codex 0.149.0부터). 서브에이전트의 샌드박스 · 승인 설정은 항상 메인의 현재 값을 따른다.
  조사용 프리셋은 developer_instructions에 "파일을 고치지 마라"고 적어 두었다.
- 프리셋 파일만 두면 메인이 잘 안 부른다. AGENTS.md 조각을 꼭 같이 넣는다.

## 공통

- spawn_agent의 `fork_turns` 기본값은 `all`(메인 대화 전체 복사)이다. 조각의 규칙대로 `"none"`을 넘긴다.
